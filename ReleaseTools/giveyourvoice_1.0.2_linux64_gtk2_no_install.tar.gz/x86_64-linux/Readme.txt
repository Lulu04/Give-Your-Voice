the Linux 64bits libraries have been compiled from sources on a Win10 machine + VirtualBox + Ubuntu Mate 18.4 64b + CMake + CMake-gui

Source for OpenAL-Soft can be found on https://github.com/kcat/openal-soft

Source for LibSndFile can be found on https://github.com/libsndfile/libsndfile

If you build them yourself from source, don't forget to rename the obtained binaries to
	libopenal.so and libsndfile.so
and put a copy in your application folder executable.
